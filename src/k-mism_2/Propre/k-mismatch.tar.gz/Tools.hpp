/* Copyright :
Author : Tatiana Rocher, tatiana.rocher@gmail.com (kangaroo algorithm) 
*/

#ifndef TOOLS_HPP
#define TOOLS_HPP

// int k_nb_letters = 128;


int CharToInt(char letter);
char IntToChar(int val);

#endif  // TOOLS_HPP
