/* Copyright :
Author : Tatiana Rocher, tatiana.rocher@gmail.com

This file contains some functions used by LCP.cpp 
and HammingDistance.cpp
*/

#include "Tools.hpp"

int CharToInt(char letter) {
    return (int) letter;
}

char IntToChar(int val) {
    return (char) val;
}
